import React from 'react';
import { AppNavigation } from './src/Navigations';
import { ProductContextProvider } from './src/context/ProductContext';
import { FavouriteContextProvider } from './src/context/FavouriteContext';

import { Provider } from 'react-redux';
import { store } from './src/redux/store';


const App = () => {


  return (
    <Provider store={store}>
      <FavouriteContextProvider>
      <ProductContextProvider>
          <AppNavigation/>
      </ProductContextProvider>
    </FavouriteContextProvider>
    </Provider>
    
    

 
  )

}

export default App