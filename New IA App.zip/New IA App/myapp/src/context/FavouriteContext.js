import React, { createContext, useState } from "react";

export const FavouriteContext = createContext()

export const FavouriteContextProvider = ({children}) => {

    const [isFavored, setIsFavored] = useState([])


    //add favourites

    const addFavs = (product) => {
        setIsFavored([...isFavored, product])
    }

    //remove favourites

    const removeFavs = (product) => {
        const newFavs = isFavored.filter((p) => p.id !== product.id)
        setIsFavored(newFavs)
    }


    return(
        <FavouriteContext.Provider
        
        value={{
            isFavored,
            add: addFavs,
            remove: removeFavs
        }}

        >
            {children}
        </FavouriteContext.Provider>
    )
}