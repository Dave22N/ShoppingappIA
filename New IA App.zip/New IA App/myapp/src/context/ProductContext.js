import React, { createContext, useState } from "react";
import {data} from '../model/ProductModel';

export const ProductContext = createContext()

export const ProductContextProvider = ({children}) => {

    const [isloading, setIsloading] = useState(true)

    setTimeout(()=> {
        setIsloading(false)
    }, 2000)
    
    return(
        <ProductContext.Provider
        value={{
            isloading,
            products: data
        }}
        >
            {children}
        </ProductContext.Provider>
         
    )
}