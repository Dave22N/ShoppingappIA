import {createSlice} from '@reduxjs/toolkit';


const initialState = {
    items: [],
    totalPrice: 0,
    totalQuantity: 0
}

export const cartSlice = createSlice({
    name: "cart",
    initialState,
    reducers: {

        addtoCart (state, action){
            const newItem = action.payload
            const exists = state.items.find(p => p.id === newItem.id)

            state.totalQuantity++

            if(!exists){
                state.items.push({
                    ...newItem,
                    qty: 1,
                    totalAmount: newItem.price
                })
                state.totalPrice = newItem.price
                
            }
            else{
                exists.qty++
                state.totalPrice = state.totalPrice += newItem.price
                exists.totalAmount = exists.totalAmount * exists.qty
            }


        },
        removeItem (state, action){
            const itemToRemove = action.payload
            const itemExists = state.items.find(p => p.id === itemToRemove.id)
            
            if(itemExists.qty === 1){
                state.items = state.items.filter(item => item.id != itemToRemove.id)
                state.totalPrice = state.totalPrice - itemToRemove.price

            }
            else{
                itemExists.qty--
                itemExists.totalAmount = itemExists.totalAmount - itemExists.price
                state.totalPrice = state.totalPrice - itemExists.price
            }
        }

    }
}) 

export const cartActions = cartSlice.actions