import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaView, Button, StyleSheet, Text, View, Alert, Image } from 'react-native';
import { TextInput } from 'react-native-paper'
import { AppScreen } from '../AppScreen';

const CheckoutScreen = () => {

    return (
        <AppScreen style={styles.screen}>
            <View>
                <Text style={styles.payment}>Pay With Credit Card</Text>
                <Text style={styles.vendor}>Cards Available</Text>
                <Image source={{
                    width: 400,
                    height: 280,
                    uri: "https://www.differencebetween.com/wp-content/uploads/2010/12/paypal-300x223.jpg"
                }} />
                <TextInput mode="outlined" label="Card Number" />
                <TextInput mode="outlined" label="PIN" />
                <Text style={styles.ship}>Shipping Details</Text>
                <TextInput mode="outlined" label="Country and Region" />
                <TextInput mode="outlined" label="Digital Address" />
                <Button color="#E74C3C" title="PAY NOW" onPress={() => Alert.alert('Payment Succesful\nItems will arrive in 2 days')} />
            </View>
        </AppScreen>
    )
}

export default CheckoutScreen

const styles = StyleSheet.create({
    screen: {
        backgroundColor: "#3498DB",
    
    },
    payment: {
        fontSize: 20,
        textAlign: 'center',
        fontWeight: 'bold'
    },
    vendor: {
        padding: 5,
        textAlign: 'center'
    },
    ship: {
        fontSize: 15,
        textAlign: 'center',
        padding: 5,
        fontWeight: 'bold',
        color: 'white'
    }
})

