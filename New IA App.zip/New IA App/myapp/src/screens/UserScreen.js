import React from "react";
import { View, StyleSheet, Image, Text } from "react-native";
import { Button } from 'react-native-paper';
import { AppScreen } from "../AppScreen";


export const MainWelcomeScreen = ({navigation}) => {
    return(
        <View style={styles.container}>
            <AppScreen style={styles.screen} >
                <View style={styles.vcontainer}>
                    <Image style={styles.image}  source={{uri:"https://media.istockphoto.com/photos/young-woman-with-shopping-bags-riding-trolley-picture-id1157459058?k=20&m=1157459058&s=612x612&w=0&h=RLSsYDNphZ-HOjInd8GvsLv2WBhfTSHV0dMRhJ-E1-4="}}/>
                    <Text style={styles.text}> Welcome To</Text>
                    <Text style={styles.text2}>TiSu Shopping Center</Text>
                </View>
                <View style={styles.btncontainer}>
                    <Button style={styles.btn} color="#E74C3C" mode="contained" icon="email" onPress={() => navigation.navigate("Login")} >Login</Button>
                    <Button style={styles.btn} color="#E74C3C" mode="contained" onPress={() => navigation.navigate("Register")}>Register</Button>
                </View> 
            </AppScreen>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex:1,
        backgroundColor: '#3498DB'
    },
    screen: {
        justifyContent: "center",
        alignItems: "center",
    },
    btncontainer: {
        padding: 10,
        backgroundColor: '#3498DB',
        width: '100%',
        marginVertical:10
    },
    btn:{
        padding:10,
        marginVertical:8,
    },
    image:{
        width: 350,
        height: 300,
        borderRadius: 20,
        marginBottom: 70,
        marginTop: 50,
        resizeMode: "contain"
    },
    vcontainer:{
        justifyContent: 'center',
        alignItems:'center',
    },
    text:{
        color: "rgba(0,0,0,0.6)", 
        fontSize: 24,
        marginTop:10
    },
    text2:{
        color: "black",
        fontSize: 30, 
        fontWeight: "600",
        alignContent: 'center'
    }
})