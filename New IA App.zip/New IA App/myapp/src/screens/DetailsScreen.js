import React from 'react';
import {StyleSheet, Text, View } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { Button, List } from 'react-native-paper';
import { useDispatch } from 'react-redux';
import { AppScreen } from '../AppScreen';
import { AppCard } from '../components/AppCard/AppCard';
import { cartActions } from '../redux/cart.redux';

const DetailsScreen = ({route}) => {

    const {product} = route.params

    const dispatch = useDispatch()

    const addToCart = () => {
        dispatch(cartActions.addtoCart(product))

    }


    return(
        <AppScreen>
            <ScrollView>
            <View>
                <AppCard style={styles.card} imgContainer={styles.imgContainer}title={product.title} price={product.price} image={product.image} items={product} />

            </View>
            <View style={styles.btnContainer}>
                <Button icon="shopping" color="#E74C3C" onPress={addToCart} mode="contained" style={styles.btn}>Add to cart</Button>
            </View>
            <List.Section title={`${product.title} Details`}>
                <List.Accordion title="Product Information" left={() => <List.Icon icon="information" />}>
                    <List.Item description={product.description} />
                </List.Accordion>
                <List.Accordion title="Reviews" left={() => <List.Icon icon="star" />}>
                    <List.Item title="5 stars." />
                </List.Accordion>
            </List.Section>
            </ScrollView>
            
        </AppScreen>
    )
}



export default DetailsScreen

const styles = StyleSheet.create({
    card: {
        backgroundColor : "#3498DB",
        width: "100%",
        marginHorizontal: 0,
        borderRadius: 5
    },
    imgContainer:{
        height:330
    },
    btnContainer:{
        padding: 10
    },
    btn:{
        padding: 10
    }
})