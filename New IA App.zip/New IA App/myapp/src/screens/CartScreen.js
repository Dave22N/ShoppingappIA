import React from 'react';
import {StyleSheet, Text, View, FlatList } from 'react-native';
import { Button } from 'react-native-paper';
import { useSelector } from 'react-redux';
import { AppScreen } from '../AppScreen';
import { CartItems } from '../components/cartItems/CartItems';

const CartScreen = ({navigation}) => {

    const cart = useSelector(state => state.cart.items)


    const totalPrice = useSelector(state => state.cart.totalPrice)

    return(
        <View style={styles.container}>
            <AppScreen style={{ flex: 1 }}>
                <FlatList 
                data={cart}
                keyExtractor={(item) => item.id}
                renderItem={({item}) => <CartItems items={item} />}

                />

                <View style={styles.buttonContent}>
                    <Text style={styles.buttonText}>Total Amount :GHC{Math.floor (totalPrice)}</Text>
                    <Button icon="cart"  color="black" onPress={() => navigation.navigate("CheckOut")} style={{backgroundColor:"#E74C3C",padding:10}} >
                        <Text>CHECKOUT</Text>
                    </Button>
                </View>

            </AppScreen>
            
        </View>
    )
}

export default CartScreen

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#3498DB"
    },
    buttonContent: {
        position: "absolute",
        bottom: 0,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        width: "100%",
        padding: 10,
        borderRadius: 6
    },
    buttonText: {
        fontSize: 16,
        fontWeight: "600",
        marginRight: 10 
    }
})