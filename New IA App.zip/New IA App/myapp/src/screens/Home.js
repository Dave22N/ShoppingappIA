import React, { useContext } from 'react';
import {StyleSheet, Text, View, FlatList } from 'react-native';
import { ProductContext } from '../context/ProductContext';
import {ActivityIndicator} from 'react-native-paper';
import { AppCard } from '../components/AppCard/AppCard';
import { AppScreen } from '../AppScreen';

const Home = ({navigation}) => {

    const {isloading, products} = useContext(ProductContext)

    if(isloading){
        return(
            <View style={styles.prodLoading}>
                <ActivityIndicator animating={true} size="large" />
                <Text style={{marginVertical: 15}}>Items Loading</Text>
            </View>
        )
    }


    return(
        <AppScreen >
            <View>
                <FlatList   data={products} keyExtractor={(item) => item.id} 
                            renderItem={({item}) => <AppCard title={item.title} 
                                                     price={item.price}
                                                     image={item.image} 
                                                     items={item} 
                                                     onPress={() => navigation.navigate("Details", {product: item})}

                                                     />}/>
            </View>
        </AppScreen>
    )
}

export default Home

const styles = StyleSheet.create({
    prodLoading: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center"
    }
})