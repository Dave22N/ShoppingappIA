import React from 'react';
import {StyleSheet, Text, View } from 'react-native';
import { AppScreen } from '../AppScreen';
import {Button, TextInput} from 'react-native-paper';

const RegisterScreen = ({navigation}) => {
    return(
        <AppScreen style={styles.screen}>
            <View style={styles.form} >
                <TextInput mode='outlined' label="Surname" />
                <TextInput mode='outlined' label="First Name" />
                <TextInput mode='outlined' label="Date Of Birth" />
                <TextInput mode='outlined' label="Gender" />
                <TextInput mode='outlined' label="E-Mail" />
                <TextInput mode='outlined' label="Password" />
                <View style={{padding:10, marginVertical:10}}>
                    <Button style={styles.bttn} color="#E74C3C" icon="email" mode="contained" onPress={() => navigation.navigate("Home")} >Register</Button>
                </View>
            </View>
            
        </AppScreen>
    )
}

export default RegisterScreen

const styles = StyleSheet.create({
    bttn:{
        padding:10
    },
    form:{
        padding:10,
        width: "100%",
        backgroundColor: "#3498DB",
        borderRadius:10
    },
    screen:{
        flex:1,
        justifyContent:'center',
        alignItems: 'center',
        backgroundColor: "#3498DB"
    }
})