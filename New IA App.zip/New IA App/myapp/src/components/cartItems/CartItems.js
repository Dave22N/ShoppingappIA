import React from "react";
import {View, Text, Image, StyleSheet} from 'react-native';
import { useDispatch } from "react-redux";
import { IconButton } from "../../IconButtons/IconButton";
import { cartActions } from "../../redux/cart.redux";

export const CartItems = ({items}) => {
    const {image, title, price, qty, totalAmount} = items

    const dispatch = useDispatch()

    const incrementQuantity = () => {
        dispatch(cartActions.addtoCart(items))
    }

    const decrementQuantity = () => {
        dispatch(cartActions.removeItem(items))
    }

    return(
        <View style={styles.container}>
            <View style={styles.imgcontainer}>
                <Image style={styles.image} source={{uri: image}} />
            </View>
            <View style={styles.body}>
                <Text style={styles.title}>{title}</Text>
                <Text style={styles.price}>GHC{price}</Text>
                <Text style={styles.totalAmount}>GHC{totalAmount}</Text>
            </View>
            <View style={styles.rightContent}>
                <IconButton onPress={decrementQuantity} iconName="minus" size={40} />
                <Text style={styles.qty}>{qty}</Text>
                <IconButton onPress={incrementQuantity} iconName="plus" size={40} />
            </View>

        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: '#E74C3C',
        padding: 10
    },
    imgcontainer: {
        height: 60,
        width : 60,
        marginRight: 16
    },
    image:{
        width: '100%',
        height: '100%'
    },
    body: {
        flex: 2
    },
    rightContent: {
        flexDirection: "row",
        alignItems: "center"
    },
    qty: {
        marginHorizontal: 16
    },
    title : {
        fontSize: 18,
        fontWeight: "600"
    },
    price : {
        fontSize: 16,
        fontWeight: "600",
        marginVertical: 5
    },
    totalAmount : {
        fontSize: 16,
        fontWeight: "600"
    }         
})