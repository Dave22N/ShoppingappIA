import React, { useContext } from "react";

import {TouchableOpacity, StyleSheet} from 'react-native';
import {AntDesign} from '@expo/vector-icons'
import { FavouriteContext } from "../../context/FavouriteContext";

export const Favourite = ({product}) => {


    const {add, remove, isFavored} = useContext(FavouriteContext)
    
    //check if favorite is saved

    const isSaved = isFavored.find(e => e.id === product.id)


    return(
        <TouchableOpacity style={styles.favs} onPress={() => !isSaved ? add(product) : remove(product)}>
            <AntDesign size={40} color={!isSaved ? "red" : "red"} name={!isSaved ? "hearto" : "heart"}/>
        </TouchableOpacity>
    )
}

const styles = StyleSheet.create({
    favs: {
        position: "absolute",
        left: 10,
        top: 30,
        zIndex: 100
    }
})