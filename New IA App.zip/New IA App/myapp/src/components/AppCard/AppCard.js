import React from "react";
import {Image, View, Text, TouchableOpacity, StyleSheet } from "react-native";
import {AntDesign} from '@expo/vector-icons'
import { Favourite } from "../Favourites/Favourites";

export const AppCard = ({title, price, image, items, onPress, style, imgContainer}) => {
    return(
        <TouchableOpacity onPress={onPress} style={[styles.card, {...style}]}>

            <Favourite product={items} />

            <View style={[styles.imageContainer, {...imgContainer}]}>
                <Image source={{uri: image}} style={{height: "100%", width:"100%"}} />
            </View>

            <View style={styles.cardBody}>
                <View style={styles.cardContent}>
                    <Text style={styles.title}>{title}</Text>
                    <Text style={styles.price}>{price}</Text>
                </View> 
                <View style={{flexDirection: "row"}}>
                    <AntDesign name="star" size={18} color="#F1C40F" />
                    <AntDesign name="star" size={18} color="#F1C40F" />
                    <AntDesign name="star" size={18} color="#F1C40F" />
                    <AntDesign name="star" size={18} color="#F1C40F" />
                    <AntDesign name="star" size={18} color="#F1C40F" />
                </View>
            </View>
        </TouchableOpacity>
    )
}

const styles = StyleSheet.create({
    card: {
        width : 400,
        backgroundColor: "#3498DB",
        paddingBottom: 10,
        marginHorizontal: 5,
        marginVertical: 5,
        borderRadius: 10,
    },
    imageContainer: {
        height: 330,
    },
    cardBody: {
        padding: 10,
    },
    cardContent: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
    },
    title: {
        fontSize: 20,
        fontWeight: "500",
        color:"black"
    },
    price: {
        fontSize: 24,
        fontWeight: "bold",
        color:"black"
    }
})