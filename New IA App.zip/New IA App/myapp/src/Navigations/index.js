import 'react-native-gesture-handler';

import React from 'react';

import { NavigationContainer} from '@react-navigation/native';
import { AuthNav } from './AuthNav';

export const AppNavigation = () => {
    return(
        <NavigationContainer>
            <AuthNav />
        </NavigationContainer>
    )
}