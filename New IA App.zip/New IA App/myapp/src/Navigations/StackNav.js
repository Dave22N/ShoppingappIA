import React from 'react';
import {createStackNavigator, TransitionPresets} from '@react-navigation/stack';
import Home from '../screens/Home';
import DetailsScreen from '../screens/DetailsScreen';


const Stack = createStackNavigator()


export const StackNav = () => {
    return(
        <Stack.Navigator screenOptions={{headerShown: false, ...TransitionPresets.BottomSheetAndroid}}>
            <Stack.Screen name="Home" component={Home} />
            <Stack.Screen name="Details" component={DetailsScreen} />
        </Stack.Navigator>
    )
}