import React from 'react';
import {createStackNavigator, TransitionPresets} from '@react-navigation/stack';
import CartScreen from '../screens/CartScreen';
import CheckoutScreen from '../screens/Checkout';


const Stack = createStackNavigator()


export const CartNav = () => {
    return(
        <Stack.Navigator screenOptions={{headerShown: false, ...TransitionPresets.BottomSheetAndroid}}>
            <Stack.Screen name="Cart" component={CartScreen} />
            <Stack.Screen name="CheckOut" component={CheckoutScreen} />
        </Stack.Navigator>
    )
}