import React from "react";

import {createBottomTabNavigator} from "@react-navigation/bottom-tabs";
import {AntDesign} from '@expo/vector-icons'
import { StackNav } from "./StackNav";
import { CartNav } from "./CartNav";

const Tab = createBottomTabNavigator()

const TabIcons = {
    Home: "home",
    Cart: "shoppingcart"
}

export const TabNav = () => {
    return(
        <Tab.Navigator screenOptions={ ({route}) => ({
            tabBarIcon: ( {size, color}) => {
                const iconName = TabIcons[route.name]
                return <AntDesign name={iconName} size={size} color={color} />
            }
            
        })}>
            <Tab.Screen name="Home" component={StackNav} />
            <Tab.Screen name="Cart" component={CartNav} />
           
        </Tab.Navigator>
    )
}