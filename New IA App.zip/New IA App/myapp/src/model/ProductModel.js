export const data = [
    {
        title: "Nike Air Max 270",
        price: "200.00",
        id: "129",
        image: "https://image-cdn.hypb.st/https%3A%2F%2Fhypebeast.com%2Fimage%2F2018%2F06%2Fnike-air-max-270-light-grey-001.jpg",
        brand: "Nike",
        colours: ["#00e0ff", "#f9ff21", "#107a8b"],
        description: "Brand New Nike Air Max 270, Sizes: Mens 42\nColours: Grey, Promo: 50% Off"
    },
    {
        title: "Gildan Plain Shirt",
        price: "20.00",
        id: "14d9",
        image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?ixid=MnwxMjA3fDB8MHxzZWFyY2h8NHx8Z2lsZGFuJTIwc2hpcnQlMjBjb2xvdXJzfGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        brand: "Gildan",
        colours: ["#00e0ff", "#f9ff21", "#107a8b"],
        description: "Plain Gildan Shirts, Sizes: Medium, Large\nColours: White,Blue,Yellow Promo: 50% Off"
    },
    {
        title: "Beats Headset",
        price: "350.00",
        id: "22f7",
        image: "https://www.techadvisor.com/cmsdata/features/3787968/beats_solo_3_deal__1__thumb800.jpg",
        brand: "Beats By Dre",
        colours: ["#00e0ff", "#f9ff21", "#107a8b"],
        description: "Brand New Quality Beats By Dre Headsets, \nColours: Purple, Promo: 50% Off"
    },
    {
        title: "Playstation 5",
        price: "3500.00",
        id: "17rt",
        image: "https://media.istockphoto.com/photos/sony-playstation-5-gift-edition-picture-id1287266528?k=20&m=1287266528&s=612x612&w=0&h=2Hdvk13JY5QNySmjdlp1t_Xpg1qm1HD_P2gXaa7cRdY=",
        brand: "Sony PlayStation",
        colours: ["#00e0ff", "#f9ff21", "#107a8b"],
        description: "Brand New PS5 with 1 controller,\nColours: White, Promo: No Promo"
    },
    {
        title: "IPhone 13",
        price: "6900.00",
        id: "18vt",
        image: "https://cdn.mos.cms.futurecdn.net/kWcJaVDKbrd548xLhKfWcc.jpg",
        brand: "Apple",
        colours: ["#00e0ff", "#f9ff21", "#107a8b"],
        description: "Brand New IPhone 13 256gb, \nColours: Blue, Promo: No Promo"
    },
    {
        title: "Dell Laptop",
        price: "7900.00",
        id: "19cy",
        image: "https://images.unsplash.com/photo-1593642702909-dec73df255d7?ixid=MnwxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=869&q=80",
        brand: "Dell",
        colours: ["#00e0ff", "#f9ff21", "#107a8b"],
        description: "Brand New Dell XPS Laptop 8gbRAM 256 SSD, \nColours: Grey, Promo: No Promo"
    },
    {
        title: "Retro Jordan 1s",
        price: "1000.00",
        id: "135t",
        image: "https://images.unsplash.com/photo-1602033693387-3531914e7185?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1029&q=80",
        brand: "Nike",
        colours: ["#00e0ff", "#f9ff21", "#107a8b"],
        description: "New Retro Jordan 1s, Sizes: Mens 42\nColours: Orange, Promo: 10% Off"
    }
]