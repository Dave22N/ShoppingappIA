import React from "react";
import { View } from "react-native";
import { Ionicons, FontAwesome5, AntDesign } from '@expo/vector-icons';

export default function Home() {
    return <View style={{backgroundColor: 'white', flex: 1, paddingTop: 55, paddingHorizontal: 20}}>
              <View style={{flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'}}>
                  <Ionicons name="ios-menu-outline" size={24} color="black" />
                  <FontAwesome5 name="motorcycle" size={24} color="black" />
                  <View style={{flexDirection: "row"}}>
                  <AntDesign name="search1" size={20} color="black" />
                  <Ionicons name="notifications-outline" size={20} color="black" />
                  </View>
                </View>
            </View>
}